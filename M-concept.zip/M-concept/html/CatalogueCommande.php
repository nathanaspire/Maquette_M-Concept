<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
<link rel="stylesheet" href="../css/navBar.css">
<link rel="stylesheet" href="../css/tableRetour.css">

</head>
<body>
     <div class="container1">
    <div class="logo">
        <a href="#"><img src="https://mconcept-textile.fr/wp-content/uploads/2018/11/mconcept.png" alt="logo"></a>
    </div>
<div class="navbar">

<div class="icon-bar" onclick="Show()">
    <i></i>
    <i></i>
    <i></i>
</div>

<ul id="nav-lists" >
    <li class="close"><span onclick="Hide()">×</span></li>
    <li><a href="M-conceptAccueille.html">Accueil</a></li>
    <li><a href="MPresentation.html">Présentation</a></li>
    <li><a href="Mevent.php">M Event</a></li>
    <li><a href="Mpro.php">M Pro</a></li>
    <li><a href="Mschool.php">M School</a></li>
    <li><a href="Msport.php">M Sport</a></li>
    <li><a href="MContact.html">Contact</a></li>
</ul>

</div>
</div>
<script>
var navList = document.getElementById("nav-lists");
function Show() {
navList.classList.add("_Menus-show");
}

function Hide(){
navList.classList.remove("_Menus-show");
}
</script>
<!-- Slideshow container -->
 <img src="../images/arras.jpg" width="100%" height="500px">   
 

 <center>   
<div class="inputTri">
    <b>Choisir la façon dont vous voulez trier pour afficher le tableaux</b>
<form action="" method="POST">
     <input type="submit" name="bouton1" value="Nom">
     <input type="submit" name="bouton2" value="Email">
     <input type="submit" name="bouton3" value="Date">
  </form>
</div>
</center>
    <?php
      $bdd = new PDO('mysql:host=localhost;dbname=mconcept;charset=utf8', 'root', 'root');
        
        
      if (isset($_POST['bouton1']))
      {
          $album = $bdd->query('SELECT id,nom,email,objet,dateJour,message FROM contact ORDER BY nom');
      }
        
      if (isset($_POST['bouton2']))
      {
          $album = $bdd->query('SELECT id,nom,email,objet,dateJour,message FROM contact ORDER BY email');
      }

      if (isset($_POST['bouton3']))
      {
          $album = $bdd->query('SELECT id,nom,email,objet,dateJour,message FROM contact ORDER BY dateJour');
      }
        
        
      
    ?>
    <?php
        echo '<center><table class="tableRetour">
                <tr>
                    <th>ID</th>
                    <th>Nom</th>
                    <th>Email</th>
                    <th>Objet</th>
                    <th>Date</th>
                    <th>Message</th>
                </tr>
                <tr>';
        while ($data = $album->fetch()) {
           echo '<td>'.$data['id']. '</td>
                 <td>'.$data['nom'].'</td>
                 <td>'.$data['email'].'</td>
                 <td>'.$data['objet'].'</td>
                 <td>'.$data['dateJour'].'</td>
                 <td>'.$data['message'].'</td>
                </tr>';
            }
        echo '</table></center>';
     ?>



  


</body>
</html>