<!doctype html>
<html lang="fr">
  <head>
    <meta charset="utf-8">
    <title>Titre de la page</title>
    <link rel="stylesheet" href="css.css">
  </head>
  <body>
<form action="" method="POST">
     <input type="submit" name="bouton1" value="envoyer">
     <input type="submit" name="bouton2" value="envoyer">
  </form>  <?php
      $bdd = new PDO('mysql:host=localhost;dbname=mconcept;charset=utf8', 'root', 'root');
        
        
      if (isset($_POST['bouton1']))
      {
          $album = $bdd->query('SELECT id,nom,email,objet,dateJour,message FROM contact ORDER BY nom');
      }
        
      if (isset($_POST['bouton2']))
      {
          $album = $bdd->query('SELECT id,nom,email,objet,dateJour,message FROM contact ORDER BY dateJour');
      }
        
        
      
    ?>
    <?php
        echo '<table>
                <tr>
                    <th>ID</th>
                    <th>Nom</th>
                    <th>Email</th>
                    <th>Objet</th>
                    <th>Date</th>
                    <th>Message</th>
                </tr>
                <tr>';
        while ($data = $album->fetch()) {
           echo '<td>'.$data['id']. '</td>
                 <td>'.$data['nom'].'</td>
                 <td>'.$data['email'].'</td>
                 <td>'.$data['objet'].'</td>
                 <td>'.$data['dateJour'].'</td>
                 <td>'.$data['message'].'</td>
                </tr>';
            }
        echo '</table>';
     ?>
  </body>
</html>