<?php

echo'
<head>
   <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>M-concept</title>

    <!-- CSS -->
    <link href="../'.$css.'/css/MconceptslideShowEvent.css" rel="stylesheet">
    <link rel="stylesheet" href="../'.$css.'/css/BasDePageEvent.css"> 
    <link rel="stylesheet" href="../'.$css.'/css/navBar.css">
    <link rel="stylesheet" href="../'.$css.'/css/MSchool.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" media="screen" href="../css/GaleriePhotoPresentation.css" />
    <!-- <link rel="stylesheet" type="text/css" href="../fancybox/jquery.fancybox-1.3.4.css" media="screen" /> -->

  <!-- <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.5.0/jquery.min.js"></script> -->
  <!-- <script src="../js/jquery-2.2.4.min.js"></script> -->

  <script src="https://cdn.jsdelivr.net/npm/jquery@3.4.1/dist/jquery.min.js"></script>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.css" />
<script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js"></script>
  <script src="../js/multislider.min.js"></script>
  <!-- <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.5.0/jquery.min.js"></script> -->
  <!-- <script type="text/javascript" src="../js/jquery.mousewheel-3.0.4.pack.js"></script> -->
  
  <script type="text/javascript">
        $(document).ready(function() {
            /*
            *   Examples - images
            */

            $("a#example1").fancybox();

        });
  </script>




   
</head>
<body style="background-color: black">
  <div class="container1">
    <div class="logo">
        <a href="#"><img src="https://mconcept-textile.fr/wp-content/uploads/2018/11/mconcept.png" alt="logo"></a>
    </div>
<div class="navbar">

<div class="icon-bar" onclick="Show()">
    <i></i>
    <i></i>
    <i></i>
</div>

<ul id="nav-lists" >
    <li class="close"><span onclick="Hide()">×</span></li>
    <li><a href="M-conceptAccueille.html">Accueil</a></li>
    <li><a href="MPresentation.html">Présentation</a></li>
    <li><a href="Mevent.php">M Event</a></li>
    <li><a href="Mpro.php">M Pro</a></li>
    <li><a href="Mschool.php">M School</a></li>
    <li><a href="Msport.php">M Sport</a></li>
    <li><a href="MContact.html">Contact</a></li>
</ul>

</div>
</div>
<script>
var navList = document.getElementById("nav-lists");
function Show() {
navList.classList.add("_Menus-show");
}

function Hide(){
navList.classList.remove("_Menus-show");
}
</script>
<div class="TopImage"><img src="https://mconcept-textile.fr/wp-content/uploads/2019/07/67363836_393415477952232_4710850289236705280_o-1.jpg" width="100%" height=""></div>

<div class="TopPage1">
  <img src="https://mconcept-textile.fr/wp-content/uploads/2018/11/mconcept.png">
  <p class="titreTop">M EVENT est uen branche dub groupe M Concept Textile</p>
            <p class="BotpageP1">Nous avons choisi de porposer des offres textiles pour les organisateurs d évènements. Un concert, un événement culturel et sportif, la visibilité qu offre le textile personnalisé est sans limite</p>
            <p class="BotpageP2">Nous proposons également la personnalisation sur place en nous déplaçant avec nos outils de personnalisation pour permettre à votre public de repartir avec son textile personnalisé.<br><b>L équipe M Concept Textile</b></p>
            <i><p>Aujourd hui le textile occupe une place prépondérante dans la communication d entreprise et évenementielle</p></i>
            <div class="backgroundPaTop"></div>
</div>


<table class="categorie">
   <tr>
       <td class="td1">CULTURE</td>
       <td class="td2">MUSIQUE</td>
       <td class="td3">SPORT</td>
       <td class="td4">VOYAGE</td>
   </tr>
</table>

<div class=" ShowRoomGammmes">
  <p class="titreMiddle"><b>DECOUVREZ NOTRE GAMME AU SHOWROOM</b></p>
  <p class="ShowRoomP">Grâce à son expertise et son expérience, notre équipe se tient à votre disposition pour vous accueillir dans notre SHOWROOMO et vous conseiller dans vos futurs projets textiles.</p>
<div id="exampleSlider">
       <div class="MS-content">
           <div class="item">
               <p><img src="../images/slideShowbot/3dSlidePhoto1.jpg"></p>
           </div>
           <div class="item">
               <p><img src="../images/slideShowbot/3dSlidePhoto2.jpg"></p>
           </div>
           <div class="item">
               <p><img src="../images/slideShowbot/3dSlidePhoto3.jpeg"></p>
           </div>
           <div class="item">
               <p><img src="../images/slideShowbot/3dSlidePhoto4.jpg"></p>
           </div>
           <div class="item">
               <p><img src="../images/slideShowbot/3dSlidePhoto5.jpg"></p>
           </div>
           <div class="item">
               <p><img src="../images/slideShowbot/3dSlidePhoto6.jpg"></p>
           </div>
           <div class="item">
               <p><img src="../images/slideShowbot/3dSlidePhoto7.jpg"></p>
           </div>
           <div class="item">
               <p><img src="../images/slideShowbot/3dSlidePhoto8.jpg"></p>
           </div>
           
       </div>
       <div class="MS-controls">
           <button class="MS-left"><i class="fa fa-chevron-left" aria-hidden="true"></i></button>
           <button class="MS-right"><i class="fa fa-chevron-right" aria-hidden="true"></i></button>
       </div>
   </div>
</div>
    <script>
    $("#exampleSlider").multislider({
        interval: 4000,
        slideAll: true,
        duration: 1500
    });
    </script>
<hr class="hrHaut" width="75%" color="#ACA59D">
<div id="content">
<div id="works">
    
        <a id="example1" href="../images/img/work-1.jpeg"><div class="work">
            
            <img src="../images/img/work-1.jpeg" height="284" width="302"/>
            <div class="triangle-gauche"></div><!-- .triangle-gauche -->
            <div class="triangle-droite"></div><!-- .triangle-droite -->
            <span>Photographie<br />Paris</span>
            
        </div><!-- .work -->
        </a>
        
        <a id="example1" href="../images/img/work-2.jpg"><div class="work">
            
            <img src="../images/img/work-2.jpg" height="284" width="302" />
            <div class="triangle-gauche"></div><!-- .triangle-gauche -->
            <div class="triangle-droite"></div><!-- .triangle-droite -->
            <span>Site<br />Claire La porta</span>
            
        </div><!-- .work -->
        </a>
        
        <a id="example1" href="../images/img/work-3.jpg"><div class="work" style="margin-right:0px">
            
            <img src="../images/img/work-3.jpg" height="284" width="302"/>
            <div class="triangle-gauche"></div><!-- .triangle-gauche -->
            <div class="triangle-droite"></div><!-- .triangle-droite -->
            <span>Site<br />NL conseil</span>
            
        </div><!-- .work -->
        </a>
        
        <a id="example1" href="../images/img/work-4.jpg"><div class="work">
            
            <img src="../images/img/work-4.jpg" height="284" width="302"/>
            <div class="triangle-gauche"></div><!-- .triangle-gauche -->
            <div class="triangle-droite"></div><!-- .triangle-droite -->
            <span>Menu CSS3<br />Site Tamento</span>
            
        </div><!-- .work -->
        </a>
        
        <a id="example1" href="../images/img/work-5.jpg"><div class="work">
            
            <img src="../images/img/work-5.jpg" height="284" width="302"/>
            <div class="triangle-gauche"></div><!-- .triangle-gauche -->
            <div class="triangle-droite"></div><!-- .triangle-droite -->
            <span>Pagination<br />Template</span>
            
        </div><!-- .work -->
        </a>
        
        <a id="example1" href="img/work-6.jpg"><div class="work" style="margin-right:0px">
            
            <img src="../images/img/work-6.jpg" height="284" width="302"/>
            <div class="triangle-gauche"></div><!-- .triangle-gauche -->
            <div class="triangle-droite"></div><!-- .triangle-droite -->
            <span>Menu bar<br />l escale</span>
            
        </div><!-- .work -->
        </a>
        
        <a id="example1" href="../images/img/work-7.jpg"><div class="work">
            
            <img src="../images/img/work-7.jpg" height="284" width="302"/>
            <div class="triangle-gauche"></div><!-- .triangle-gauche -->
            <div class="triangle-droite"></div><!-- .triangle-droite -->
            <span>Template<br />Nike</span>
            
        </div><!-- .work -->
        </a>
        
        <a id="example1" href="../images/img/work-8.jpg"><div class="work">
            
            <img src="../images/img/work-8.jpg" height="284" width="302"/>
            <div class="triangle-gauche"></div><!-- .triangle-gauche -->
            <div class="triangle-droite"></div><!-- .triangle-droite -->
            <span>Rendu 3D<br />Krakoul</span>
            
        </div><!-- .work -->
        </a>
        
        <a id="example1" href="../images/img/work-8.jpg"><div class="work" style="margin-right:0px">
            
            <img src="../images/img/work-8.jpg" height="284" width="302"/>
            <div class="triangle-gauche"></div><!-- .triangle-gauche -->
            <div class="triangle-droite"></div><!-- .triangle-droite -->
            <span>Formulaire<br />Equilibre</span>
            
        </div><!-- .work -->
        </a>
        
        <a id="example1" href="../images/img/work-8.jpg"><div class="work">
            
            <img src="../images/img/work-8.jpg" height="284" width="302"/>
            <div class="triangle-gauche"></div><!-- .triangle-gauche -->
            <div class="triangle-droite"></div><!-- .triangle-droite -->
            <span>Accès<br />Equilibre</span>
            
        </div><!-- .work -->
        </a>
        
        <a id="example1" href="../images/img/work-8.jpg"><div class="work">
            
            <img src="../images/img/work-8.jpg" height="284" width="302"/>
            <div class="triangle-gauche"></div><!-- .triangle-gauche -->
            <div class="triangle-droite"></div><!-- .triangle-droite -->
            <span>Sketch<br />Ipad</span>
            
        </div><!-- .work -->
        </a>
        
        <a id="example1" href="../images/img/work-8.jpg"><div class="work" style="margin-right:0px">
            
            <img src="../images/img/work-8.jpg" height="284" width="302"/>
            <div class="triangle-gauche"></div><!-- .triangle-gauche -->
            <div class="triangle-droite"></div><!-- .triangle-droite -->
            <span>Réseaux sociaux<br />Template</span>
            
        </div><!-- .work -->
        </a>
    
  </div><!-- #works -->
    
</div><!-- #content -->
<hr class="hrBas" width="75%" color="#ACA59D">


<!-- <img src="../images/arras.jpg" width="100%" height="500px"> -->
<div class="partenaireDiv">
<table class="partenaire">
   <tr>
       <td class="partenairetd1"><img src="https://mconcept-textile.fr/wp-content/uploads/2018/11/mconcept.png" alt="logo"></td>
       <td class="partenairetd2"><img src="https://mconcept-textile.fr/wp-content/uploads/2018/11/mconcept.png" alt="logo"></td>
       <td class="partenairetd3"><img src="https://mconcept-textile.fr/wp-content/uploads/2018/11/mconcept.png" alt="logo"></td>
       <td class="partenairetd4"><img src="https://mconcept-textile.fr/wp-content/uploads/2018/11/mconcept.png" alt="logo"></td>
   </tr>
   <tr>
       <td class="partenairetd1"><img src="https://mconcept-textile.fr/wp-content/uploads/2018/11/mconcept.png" alt="logo"></td>
       <td class="partenairetd2"><img src="https://mconcept-textile.fr/wp-content/uploads/2018/11/mconcept.png" alt="logo"></td>
       <td class="partenairetd3"><img src="https://mconcept-textile.fr/wp-content/uploads/2018/11/mconcept.png" alt="logo"></td>
       <td class="partenairetd4"><img src="https://mconcept-textile.fr/wp-content/uploads/2018/11/mconcept.png" alt="logo"></td>
   </tr>
   <tr>
       <td class="partenairetd1"><img src="https://mconcept-textile.fr/wp-content/uploads/2018/11/mconcept.png" alt="logo"></td>
       <td class="partenairetd2"><img src="https://mconcept-textile.fr/wp-content/uploads/2018/11/mconcept.png" alt="logo"></td>
       <td class="partenairetd3"><img src="https://mconcept-textile.fr/wp-content/uploads/2018/11/mconcept.png" alt="logo"></td>
       <td class="partenairetd4"><img src="https://mconcept-textile.fr/wp-content/uploads/2018/11/mconcept.png" alt="logo"></td>
   </tr>
</table>


<center>
<table class="reseauxsociaux">
   <tr>
       <td class="obligations">Obligations</td>
       <td class="reseauxsociauxBlock">Réseaux sociaux</td>
   </tr>
   <tr>
       <td class="obligations">obligation 1</td>
       <td class="reseauxsociauxBlock"><img src="https://mconcept-textile.fr/wp-content/uploads/2019/01/facebook-logo.png" alt="logo"><a href="https://www.facebook.com/M-Concept-Textile-998883796902802/?__tn__=%2Cd%2CP-R&eid=ARD19Zz98S6Zwg7zsUNiQ467C1faYg14DUz_9ipEi-Ap0y-9EOmD4ad2-bnSd2P5e4hh7j9bnS6zHLkC"> Faceboock</a></td>
   </tr>
   <tr>
       <td class="obligations">obligations 2</td>
       <td class="reseauxsociauxBlock"><img src="https://mconcept-textile.fr/wp-content/uploads/2019/01/icon.png"><a href="https://www.instagram.com/mconcept.textile/"> Instagram</a></td>
   </tr>
</table>
</center>
</div>
    </body>';

?>