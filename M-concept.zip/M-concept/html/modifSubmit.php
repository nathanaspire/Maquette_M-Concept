<?php

include '../php/connectSql.php';

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

$newName = generateRandomString(10);

move_uploaded_file($newName, "/mesUploads/".$newName);

$sql = "UPDATE pictures SET valeur='". $newName."' WHERE id=". $_GET['id'];
$res = update($sql);
var_dump($res);