<?php
require '../vendor/autoload.php';
$ua_info = parse_user_agent();
$css = "css";
if($ua_info['browser'] == "Firefox"){
  $css ="ffCss";
} else {
  $css = "chromeCss";
}
