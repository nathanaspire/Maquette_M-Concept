<?php

	
    



  function request($req){

  	$db_username = 'root';
    $db_password = 'root';
    $db_name     = 'mconcept';
    $db_host     = 'localhost';

  	$db = mysqli_connect($db_host, $db_username, $db_password,$db_name)
           or die('could not connect to database');
    $monRes = array();
    $exec_requete = mysqli_query($db,$req);
    while($row = $exec_requete->fetch_assoc()) {
        $monRes[] = $row;
    }
    mysqli_close($db);
    return $monRes;
  }

  function update($req){

  	$db_username = 'root';
    $db_password = 'root';
    $db_name     = 'mconcept';
    $db_host     = 'localhost';

  	$db = mysqli_connect($db_host, $db_username, $db_password,$db_name)
           or die('could not connect to database');
    $exec_requete = mysqli_query($db,$req);
    mysqli_close($db);
    return $exec_requete;
  }