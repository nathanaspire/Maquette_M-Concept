<?php
echo'<head>
   <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>M-concept</title>

    <!-- CSS -->
    
    <link rel="stylesheet" href="../css/BasDePage.css">
    <link rel="stylesheet" href="../css/navBar.css">
    <link rel="stylesheet" href="../css/input.css">
    <!-- Font Awesome -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">

</head>
<body style="background-color: black">
  <div class="container1">
    <div class="logo">
        <a href="#"><img src="https://mconcept-textile.fr/wp-content/uploads/2018/11/mconcept.png" alt="logo"></a>
    </div>
<div class="navbar">

<div class="icon-bar" onclick="Show()">
    <i></i>
    <i></i>
    <i></i>
</div>

<ul id="nav-lists" >
    <li class="close"><span onclick="Hide()">×</span></li>
    <li><a href="../html/M-conceptAccueille.html">Accueil</a></li>
    <li><a href="../html/MPresentation.html">Présentation</a></li>
    <li><a href="../html/Mevent.php">M Event</a></li>
    <li><a href="../html/Mpro.php">M Pro</a></li>
    <li><a href="../html/Mschool.php">M School</a></li>
    <li><a href="../html/Msport.php">M Sport</a></li>
    <li><a href="../html/Mcontact.html">Contact</a></li>
</ul>

</div>
</div>
<script>
var navList = document.getElementById("nav-lists");
function Show() {
navList.classList.add("_Menus-show");
}

function Hide(){
navList.classList.remove("_Menus-show");
}
</script>
<!-- Slideshow container -->
 <div class="Arras"><img src="../images/arras.jpg" width="100%" height=""></div>';
 
// On commence par récupérer les champs
if(isset($_POST['nom']))      $nom=$_POST['nom'];
else      $nom="";

if(isset($_POST['email']))      $email=$_POST['email'];
else      $email="";

if(isset($_POST['objet']))      $objet=$_POST['objet'];
else      $objet="";

if(isset($_POST['dateJour']))      $dateJour=$_POST['dateJour'];
else      $dateJour="";

if(isset($_POST['message']))      $message=$_POST['message'];
else      $message="";



// On vérifie si les champs sont vides
if(empty($nom) OR empty($email) OR empty($objet) OR empty($dateJour) OR empty($message))
    {
    echo '<center><hr class="hrHaut" width="75%" color="#ACA59D"><div class="input"><font class="return" color="red">Attention, un des champs est vide !</font> <form action="../html/MContact.html"><input type="submit" value="Retourner à la page Contact" name="retour"/></form></div><hr class="hrBas" width="75%" color="#ACA59D"></center>';
    }

// Aucun champ n'est vide, on peut enregistrer dans la table
else     
    {
    //   if(isset($_POST['message'])){
    //     $entete  = 'MIME-Version: 1.0' . "\r\n";
    //     $entete .= 'Content-type: text/html; charset=utf-8' . "\r\n";
    //     $entete .= 'From: ' . $_POST['email'] . "\r\n";

    //     $messageMail = '<h1>Message envoyé depuis la page Contact de monsite.fr</h1>
    //     <p><b>Nom : </b>' . $_POST['nom'] . '<br>
    //     <b>Email : </b>' . $_POST['email'] . '<br>
    //     <b>Objet : </b>' . $_POST['objet'] . '<br>
    //     <b>date du Jour : </b>' . $_POST['dateJour'] . '<br>
    //     <b>Message : </b>' . $_POST['message'] . '</p>';

    //     $retour = mail('nathan.aspirena@gmail.com', 'Envoi depuis page Contact', $messageMail, $entete);
        
    // }

       // connexion à la base
$connect = mysqli_connect('localhost', 'root', 'root', 'mconcept'); 
// sélection de la base  

   if (mysqli_connect_errno())
   {
   echo "Failed to connect to MySQL: " . mysqli_connect_error();
   }
    
    // on écrit la requête sql
    $sql = "INSERT INTO contact(id, nom, email, objet, dateJour, message) VALUES('0','$nom','$email','$objet','$dateJour','$message')";
    
    // on insère les informations du formulaire dans la table
    $res = $connect->query($sql) or die('Erreur SQL !'.$sql.'<br>'.mysqli_error());

    // on affiche le résultat pour le visiteur
    echo"<head><link rel='stylesheet' href='../css/alignementFormRetour.css' />
    <link rel='stylesheet' href='../css/input.css'></head>";
    echo"<center>";
    echo"<fieldset>";
    echo "<h1>Votre demande a bien été envoyé</h1>" ;
    echo"<table class='returnForm'>
    <tr>
        <td class='nom'><b>Nom :</b></td>
        <td class=''>".$_POST['nom']."</td>
    </tr>
    <tr>
        <td class='email'><b>Email :</b></td>
        <td class=''>".$_POST['email']."</td>
    </tr>
    <tr>
        <td class='objet'><b>Objet :</b></td>
        <td class=''>".$_POST['objet']."</td>
    </tr>
    <tr>
        <td class='dateJour'><b>Date du jour :</b></td>
        <td class=''>".$_POST['dateJour']."</td>
    </tr>
    <tr>
        <td class='message'><b>Votre messsage :</b></td>
        <td class=''>".$_POST['message']."</td>
    </tr>
    </table>";
    // echo"<label>nom :</label>".$_POST['nom']."<br>";
    //  echo " <label>  Email :</label>".$_POST['email']."<br>";
    //   echo "<label>   Objet :</label>".$_POST['objet']."<br>";
    //   echo "<label>   La date du jour :</label>".$_POST['dateJour']."<br>";
    //    echo "<label>   Votre Message :</label>".$_POST['message']."<br>";
    echo"<form action='../html/M-conceptAccueille.html'><input type='submit' value='Accueil' name='Accueil'/></form><br>";
    echo"</fieldset>";
    echo"</center>";

    mysqli_close($connect);  // on ferme la connexion
    } 
    echo'<center>
<table class="reseauxsociaux">
   <tr>
       <td class="obligations">Obligations</td>
       <td class="reseauxsociauxBlock">Réseaux sociaux</td>
   </tr>
   <tr>
       <td class="obligations">obligation 1</td>
       <td class="reseauxsociauxBlock"><img src="../icone/facebook.png" alt="logo"><a href="https://www.facebook.com/M-Concept-Textile-998883796902802/?__tn__=%2Cd%2CP-R&eid=ARD19Zz98S6Zwg7zsUNiQ467C1faYg14DUz_9ipEi-Ap0y-9EOmD4ad2-bnSd2P5e4hh7j9bnS6zHLkC"> Faceboock</a></td>
   </tr>
   <tr>
       <td class="obligations">obligations 2</td>
       <td class="reseauxsociauxBlock"><img src="../icone/insta.png"> <a href="https://www.instagram.com/mconcept.textile/">Instagram</a></td>
   </tr>
</table>
</center>';

?> 